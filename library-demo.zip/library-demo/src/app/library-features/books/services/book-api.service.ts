import { IBooks } from './../../../models/model';
import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core-services/rest.service';
import { Observable } from 'rxjs';
import { ApplicationConstants } from '../../../constants/applicationConstants';

@Injectable({
  providedIn: 'root'
})
export class BookApiService {

  constructor(private bookListService: RestService<IBooks[]>, private bookAddService: RestService<IBooks>) { }

   /* to get the list of  books from database */
   public getBooks(bookId: string = ''): Observable<IBooks[]> {
    return this.bookListService.getData(ApplicationConstants.basePath, ApplicationConstants.booksList,
      ApplicationConstants.contentTYpe, bookId);

  }

  /* to delete the from database */
  public deleteBook(bookId: string = ''): Observable<IBooks[]> {
    return this.bookListService.deleteData(bookId,ApplicationConstants.basePath, ApplicationConstants.booksList,
      ApplicationConstants.contentTYpe, ApplicationConstants.contentTYpe);

  }

  /* to add book to database */
  public addBook(bookData: IBooks): Observable<IBooks> {
    return this.bookAddService.postData(bookData, ApplicationConstants.basePath, ApplicationConstants.booksList,
      ApplicationConstants.contentTYpe, ApplicationConstants.contentTYpe);
  }

  /* to get a single book item from database */
  public getBook(bookId: string = ''): Observable<IBooks> {
    return this.bookAddService.getData(ApplicationConstants.basePath, ApplicationConstants.booksList,
      ApplicationConstants.contentTYpe, bookId);

  }
  /* to add book to database */
  public updateBook(bookData: IBooks, bookId: string): Observable<IBooks> {
    return this.bookAddService.putData(bookData, ApplicationConstants.basePath, ApplicationConstants.booksList,
      ApplicationConstants.contentTYpe, ApplicationConstants.contentTYpe, bookId);
  }
}
