import { CustomModule } from './../custom/custom.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomSearchRoutingModule } from './custom-search-routing.module';
import { BookSearchComponent } from './book-search/book-search.component';


@NgModule({
  declarations: [BookSearchComponent], 
  imports: [
    CommonModule,
    CustomSearchRoutingModule,
    CustomModule
  ]
})
export class CustomSearchModule { }
