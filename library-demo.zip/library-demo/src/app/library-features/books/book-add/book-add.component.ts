import { BookApiService } from './../services/book-api.service';
import { IBooks } from "./../../../models/model";
import { Component, OnInit } from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from "@angular/forms";
import { ApplicationConstants } from "../../../constants/applicationConstants";
import { Router, ActivatedRoute } from "@angular/router";


@Component({
  selector: "app-book-add",
  templateUrl: "./book-add.component.html",
  styleUrls: ["./book-add.component.css"]
})
export class BookAddComponent implements OnInit {
  public addBookForm: FormGroup;
  public bookId: string;
  public categoryList: string[];
  public bookItem = IBooks;
  /* add book form fields using reactive forms*/
  public bookTitle = new FormControl("", [Validators.required]);
  public bookDescription = new FormControl("", [Validators.required]);
  public bookCategory = new FormControl("", [Validators.required]);
  public bookAuthor = new FormControl("");
  public bookPublisher = new FormControl("");
  public bookCount = new FormControl("", [
    Validators.required,
    Validators.pattern(ApplicationConstants.numericLessThanHundred)
  ]);

  constructor(private fb: FormBuilder, private route: ActivatedRoute, private router: Router, private bookApi: BookApiService) {
    /* to read the id from the url will be used for checking add/edit */
    this.route.params.subscribe( params => this.bookId = params["id"]);

    /* the form is build with its from elements */
 
    this.addBookForm = this.fb.group({
      bookTitle: this.bookTitle,
      bookDescription: this.bookDescription,
      bookCategory: this.bookCategory,
      bookAuthor: this.bookAuthor,
      bookPublisher: this.bookPublisher,
      bookCount: this.bookCount
    });

  }

  ngOnInit() {
    /* to get the list of categories */
    this.categoryList = ApplicationConstants.bookCategories;

    /* to check the form is add /edit and then getting the book details */
    
    if(this.bookId){
      this.getBook();

    }
  }

  /* to add new used to database  */

  public onSubmit(): void {
    if (this.addBookForm.valid) {

      /* to prepare the data for update/ add */
   
      const addBook: IBooks = {
        bookTitle: this.bookTitle.value,
        bookDescription: this.bookDescription.value,
        bookCategory: this.bookCategory.value,
        bookAuthor: this.bookAuthor.value,
        bookPublisher: this.bookPublisher.value,
        bookCount: this.bookCount.value
      };
      /* for edit we will update the data by calling update method */
      if(this.bookId){
        this.bookApi.updateBook(addBook, this.bookId).subscribe((data) => {
          this.router.navigateByUrl('/books');
       })
      }else {
  
      this.bookApi.addBook(addBook).subscribe((data) => {
        this.router.navigateByUrl('/books');
     })
    }
    } else {
      Object.keys(this.addBookForm.controls).forEach(key => {
        this.addBookForm.controls[key].markAsDirty();
      });
    }
  }
/* to go back to list screen from add*/
  public goToBookList() {
    this.router.navigateByUrl("/books");
  }
/* method the read the data for edit & patch to the form*/
  public getBook(){
    
    this.bookApi.getBook(this.bookId).subscribe((data) => {
  
      if(data)        
       this.addBookForm.patchValue({
        bookTitle: data.bookTitle,
        bookDescription: data.bookDescription,
        bookCategory: data.bookCategory,
        bookAuthor: data.bookAuthor,
        bookPublisher: data.bookPublisher,
        bookCount: data.bookCount
       })
     
    });

  }
}
