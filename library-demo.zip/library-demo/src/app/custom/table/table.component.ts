import { IBooks } from './../../models/model';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

  /* input to receive headers dynamically */

  @Input('tableHeaders') tableHeaders: string[];

   /* input to receive table details dynamically to display in grid*/
  @Input('tableBody') tableBody:  IBooks[];


  constructor() { }

  ngOnInit() {
  }

}
