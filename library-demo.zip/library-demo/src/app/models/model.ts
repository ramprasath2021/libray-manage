export class IBooks {
  bookTitle: string;
  bookDescription: string;
  bookCategory: string;
  bookAuthor: string;
  bookPublisher: string;
  bookCount: number;
  id?: number;
}
