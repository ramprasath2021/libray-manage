import { CustomSearchModule } from './custom-search/custom-search.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HeaderComponent } from './common-modules/components/shared/header/header.component';
import { FooterComponent } from './common-modules/components/shared/footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
 ],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
