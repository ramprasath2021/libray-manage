import { IBooks } from "./../../../models/model";
import { BookApiService } from "./../services/book-api.service";
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-book-list",
  templateUrl: "./book-list.component.html",
  styleUrls: ["./book-list.component.css"]
})
export class BookListComponent implements OnInit {
  public bookList: IBooks[];

  constructor(private bookApi: BookApiService, private router: Router) {}

  ngOnInit() {
    /* to get the list of books*/
    this.getListOfBooks();
  }
  /* method to get the list of books from api*/
  public getListOfBooks() {
    this.bookApi.getBooks().subscribe(data => {
      this.bookList = data;
    });
  }
  /* to navigate to  add book from the list */
  public gotoAddBook() {
    this.router.navigateByUrl("/books/add");
  }
  /* to navigate to  edit book from the list */
  public gotoEditBook(id: number) {
    const editUrl = `/books/edit/${id}`;
    this.router.navigateByUrl(editUrl);
  }
  /* to delete any certain book from the list */
  public deleteBook(id: number) {
    if (confirm("Are you sure you want to delete?")) {
      this.bookApi.deleteBook(id.toString()).subscribe(data => {
        /* to get the list of books after delete*/
        this.getListOfBooks();
      });
    }
  }
}
