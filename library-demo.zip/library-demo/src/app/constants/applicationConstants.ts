export class ApplicationConstants{
    public static basePath  = 'http://localhost:3000/';
    public static contentTYpe = 'application/json';
    public static booksList  = 'books';

    /* validation rules*/

    public static numericLessThanHundred: string = "^[1-9][0-9]?$|^100$";

     /* book categories*/
     public static bookCategories: string[] = ["Biographies", "Comics", "Computers"]
}